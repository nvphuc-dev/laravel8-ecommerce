<footer class="footer mt-auto">
	<div class="copyright bg-white">
		<p>
			&copy; <span id="copy-year">2021</span> Copyright Full Stack by
			<a class="text-primary" href="https://www.facebook.com/KenvinNguyen.CB/" target="_blank">Kenvin Nguyen</a>
		</p>
	</div>
	<script>
		var d = new Date();
		var year = d.getFullYear();
		document.getElementById("copy-year").innerHTML = year;
	</script>
</footer>